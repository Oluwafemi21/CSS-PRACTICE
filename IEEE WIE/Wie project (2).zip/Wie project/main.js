// GET HTML ELEMENTS
const menuBtn = document.getElementById('menu');
const closeBtn = document.getElementById('close');
const mobileNav = document.getElementById('nav');

// ADD EVENTLISTENER
menuBtn.addEventListener('click', () => {
    mobileNav.style.left = 0;
})